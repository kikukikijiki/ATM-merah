package newpackage;
/**
 *
 * @author Dava
 */
public class DepositSlot {

   public boolean isEnvelopeReceived() {
      return true; // deposit envelope was received
   } 
} 